<div class="collapse" id="showmessages">
  <div class="well">
          <table class="table table-hover">
            <thead>
              <tr>
                  <th>用户</th>
                  <th>标题</th>
                  <th>正文</th>
              </tr>  
            </thead>

            <tbody>
              <tr v-for="message in messages" >
                  <td>@{{message.user.name}}</td>
                  <td>@{{message.title}}小时</td>
                  <td>@{{message.content}}</td>
              </tr>
            </tbody>

          </table>
  
  </div>
</div>